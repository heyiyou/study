function Cat() {
    return (
      <div>
        <p>고양이</p>
        <p>야옹이</p>
        <p>키티</p>
      </div>
    );
  }
  export default Cat; // 이 컴포넌트 Cat 을 다른 파일에서 사용할 수 있도록 내보내기(export) 설정
  