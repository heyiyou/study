function Dog() {
    return (
      <div>
        <p>개</p>
        <p>멍멍이</p>
        <p>두리</p>
      </div>
    );
  }
  export default Dog;
  