import React, { useState } from 'react';
import './test.css';

const CARDS = [
  'DarkMagician',
  'BlueEyesWhiteDragon',
  'RedEyesBlackDragon',
  'Kuriboh',
  'SummonedSkull',
  'DarkMagicianGirl',
];
const TIERS = ['UR', 'SR', 'R', 'N'];                                            //  useState 배열
const rand = (max) => Math.floor(Math.random() * max);
/* ───────── 카드 한 장 ───────── */
function Card({ name, tier }) {                            // 컴포넌트인데 이건 클래스명도 동적으로 바꾸고 안에 있는 텍스트를 자동바꿔줌
  return (
    <div className={`card ${name} ${tier}`}>
      <span className="label">
        {name.replace(/([A-Z])/g, ' $1').trim()} ― {tier}
      </span>
    </div>
  );
}

/* ───────── 카드 묶음(단순 컨테이너) ───────── */
function CardArea({ children }) {
  return <div id="card_area">{children}</div>;
}

/* ───────── 메인 ───────── */
export default function App() {
    /* 뽑기로 얻은 카드(박스) */
  const [box, setBox] = useState([]);

  /* 파티 / 적 카드 예시(원하면 수정) */
  const [party] = useState([
    { name: 'DarkMagician', tier: 'UR' },
    { name: 'Kuriboh', tier: 'N' },
    { name: 'BlueEyesWhiteDragon', tier: 'SR' },
  ]);

  const [enemy] = useState([
    { name: 'dorwheldkajfl', tier: 'SR' },
    { name: 'dorwheldkdhfmsWhrekfl', tier: 'SR' },
    { name: 'dorwheldkdhlsWhrekfl', tier: 'SR' },
    { name: 'dorwheldkdhfmsWHrvkf', tier: 'SR' },
    { name: 'dorwheldkdhlsWhrvkf', tier: 'SR' },
  ]);

  // 🟢 에러 1: 함수 이름은 pull인데 gacha로 부름 → 이름 맞춰줌                   /* 가챠 1회 */
  const gacha = () => {
    const pick = CARDS[rand(CARDS.length)];
    const tier = TIERS[rand(TIERS.length)];
    setBox([...box, { name: pick, tier }]);
  };
/*
  function pull() {
  const pick = CARDS[rand(CARDS.length)];
  const tier = TIERS[rand(TIERS.length)];
  setBox([...box, { name: pick, tier }]);
}
*/



                                        // 🟢에러 2: 'my'라는 상태 없음 → box를 보여주려는 것이라면 box로 변경 내가 지정함
  return (
    <>
      <h2>파티 1</h2>
      <CardArea>
        {party.map((character, index) => (
          <Card key={index} name={character.name} tier={character.tier} />
        ))}
      </CardArea>

      <h2>보유</h2>
      <button onClick={gacha}>카드 1뽑</button>
      <CardArea>
        {box.map((character, index) => (
          <Card key={index} name={character.name} tier={character.tier} />
        ))}
      </CardArea>

      <h2>적</h2>
      <CardArea>
        {enemy.map((character, index) => (
          <Card key={index} name={character.name} tier={character.tier} />
        ))}
      </CardArea>
    </>
  );
}
